var  {validateRegister, 
    validateEmailResetpassword,
    validateChangePassword} = require('./authValidator');

module.exports = {
    validateRegister, 
    validateEmailResetpassword,
    validateChangePassword
}